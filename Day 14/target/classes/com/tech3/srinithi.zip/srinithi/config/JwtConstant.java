package com.tech3.srinithi.config;


public class JwtConstant {
	
	public static final String SECRET_KEY="kjhgtyedyesrdtfyhuiytiyuiyitu5ryguky7i6r5ydfhkgytrysdfh";
	public static final String JWT_HEADER="Authorization";

}