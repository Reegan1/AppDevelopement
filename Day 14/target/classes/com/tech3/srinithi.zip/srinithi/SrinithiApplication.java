package com.tech3.srinithi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrinithiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrinithiApplication.class, args);
	}

}
