package com.tech3.srinithi.user.domain;

public class UserRole {

}
